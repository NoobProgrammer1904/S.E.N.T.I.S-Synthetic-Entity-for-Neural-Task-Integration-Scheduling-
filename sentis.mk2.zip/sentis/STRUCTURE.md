# S.E.N.T.I.S. Repository Structure
> **Last Updated:** 2026-09-10 17:18:30 UTC
> **Environment:** Ubuntu 22.04 LTS (WSL2) | RTX 3060 12GB

```text
.
├── Modelfile
├── README.md
├── S.E.N.T.I.S .gitignore
├── STRUCTURE.md
├── auto_commit.py
├── core
│   ├── __init__.py
│   ├── engine.py
│   └── main.py
├── requirements.txt
├── sentis_output.wav
├── sentis_tts.py
├── static
│   └── index.html
└── voices
    └── jarvis_ref.wav
```
