import os
import torch
from TTS.api import TTS


class SentisVoiceEngine:
    def __init__(self, reference_wav_path: str):
        os.environ["COQUI_TOS_AGREED"] = "1"

        print("[*] Initializing XTTS v2 on GPU (CUDA)...")
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

        self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(self.device)
        self.ref_wav = reference_wav_path

        if not os.path.exists(self.ref_wav):
            raise FileNotFoundError(f"[!] Target reference audio file missing: {self.ref_wav}")

    def synthesize(self, text: str, output_filename: str = "sentis_output.wav"):
        print(f"[*] Processing voice generation: '{text}'")
        self.tts.tts_to_file(
            text=text,
            speaker_wav=self.ref_wav,
            language="en",
            file_path=output_filename
        )
        print(f"[+] Transmission compiled: {output_filename}")
        return output_filename


if __name__ == "__main__":
    engine = SentisVoiceEngine(reference_wav_path="voices/jarvis_ref.wav")
    engine.synthesize("testing sentis voice", "test.wav")