from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import Response, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn

from core.engine import SentisCore
from sentis_tts import SentisVoiceEngine

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

core = SentisCore(model_name="llama3:8b-instruct-q4_K_M")
voice = SentisVoiceEngine(
    reference_wav_path=str(Path.home() / "sentis" / "voices" / "jarvis_ref.wav")
)


class ChatRequest(BaseModel):
    user_id: str
    message: str


class TTSRequest(BaseModel):
    text: str


@app.post("/api/chat")
async def chat(req: ChatRequest):
    response_text = await core.generate_response(req.user_id, req.message)
    return {"response": response_text}


@app.post("/api/chat/speak")
async def chat_and_speak(req: ChatRequest):
    response_text = await core.generate_response(req.user_id, req.message)
    output_path = voice.synthesize(response_text, output_filename="sentis_output.wav")
    return {"response": response_text, "audio_file": output_path}


@app.post("/api/tts")
async def tts_endpoint(req: TTSRequest):
    output_path = voice.synthesize(req.text, output_filename="sentis_output.wav")
    with open(output_path, "rb") as f:
        audio_bytes = f.read()
    return Response(content=audio_bytes, media_type="audio/wav")


@app.get("/")
async def root():
    return FileResponse("static/index.html")


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)