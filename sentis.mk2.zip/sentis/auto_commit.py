import time
import subprocess
from pathlib import Path

print("[S.E.N.T.I.S.] Auto-commit daemon active. Monitoring repo...")

while True:
    try:
        status = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True)
        if status.stdout.strip():
            subprocess.run(["git", "add", "."])
            subprocess.run(["git", "commit", "-m", f"auto: checkpoint sync @ {time.strftime('%Y-%m-%d %H:%M:%S')}"])
            print(f"[S.E.N.T.I.S.] Checkpointed changes at {time.strftime('%H:%M:%S')}")
        time.sleep(300)
    except KeyboardInterrupt:
        print("\n[S.E.N.T.I.S.] Auto-commit daemon terminated.")
        break
